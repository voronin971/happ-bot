import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, CallbackQueryHandler,
    MessageHandler, filters, ContextTypes
)

# ─── НАСТРОЙКИ ───────────────────────────────────────────────
TOKEN = "8610694636:AAEOzF4ecvzwFq0oGneHswobqsCs5k9wWbg"
ADMIN_ID = 1922433958
CARD = "2202 2085 7695 6230 (Сбер)"
PRICE = 120
VPN_NAME = "Happ VPN"
CONTACT = "@BimiiVPN_bot"  # или твой личный тг

logging.basicConfig(level=logging.INFO)

# ─── ГЛАВНОЕ МЕНЮ ─────────────────────────────────────────────
def main_menu():
    keyboard = [
        [InlineKeyboardButton("💳 Купить VPN — 120 ₽", callback_data="buy")],
        [InlineKeyboardButton("❓ Как это работает", callback_data="how")],
        [InlineKeyboardButton("📱 Установка", callback_data="install")],
        [InlineKeyboardButton("🌍 Зачем VPN в России", callback_data="why")],
        [InlineKeyboardButton("💬 Поддержка", callback_data="support")],
    ]
    return InlineKeyboardMarkup(keyboard)

# ─── /start ───────────────────────────────────────────────────
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        f"👋 Привет! Это *{VPN_NAME}* — быстрый VPN для обхода блокировок в России.\n\n"
        "🔓 Разблокирует всё что нужно\n"
        "⚡ Быстрый и стабильный\n"
        "📱 Работает на телефоне и ПК\n"
        f"💰 Всего *{PRICE} ₽/месяц*\n\n"
        "Выбери что тебя интересует 👇"
    )
    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=main_menu())

# ─── КНОПКИ ───────────────────────────────────────────────────
async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == "buy":
        keyboard = [[InlineKeyboardButton("✅ Я оплатил — отправить чек", callback_data="paid")],
                    [InlineKeyboardButton("◀️ Назад", callback_data="back")]]
        text = (
            f"💳 *Оплата {VPN_NAME}*\n\n"
            f"Сумма: *{PRICE} ₽*\n"
            f"Карта: `{CARD}`\n\n"
            "📌 *Как оплатить:*\n"
            "1. Переведи 120 ₽ на карту выше\n"
            "2. Сделай скриншот перевода\n"
            "3. Нажми кнопку ниже и отправь скрин\n\n"
            "⏱ После проверки получишь ключ в течение 5–15 минут"
        )
        await query.edit_message_text(text, parse_mode="Markdown",
                                      reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == "paid":
        keyboard = [[InlineKeyboardButton("◀️ Назад", callback_data="back")]]
        text = (
            "📸 *Отправь скриншот оплаты*\n\n"
            "Просто прикрепи картинку в этот чат — я передам её на проверку.\n\n"
            "⏱ Ключ придёт в течение 5–15 минут после подтверждения."
        )
        context.user_data["waiting_receipt"] = True
        await query.edit_message_text(text, parse_mode="Markdown",
                                      reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == "how":
        keyboard = [[InlineKeyboardButton("◀️ Назад", callback_data="back")]]
        text = (
            "⚙️ *Как работает Happ VPN*\n\n"
            "Happ — это VPN на базе протокола *VLESS/Xray*, специально настроенный "
            "для обхода белых списков (DPI) в России.\n\n"
            "🔒 Твой трафик шифруется и идёт через наш сервер — сайты видят адрес сервера, "
            "а не твой реальный.\n\n"
            "✅ *Что разблокирует:*\n"
            "— Instagram, YouTube без тормозов\n"
            "— Discord, Twitch\n"
            "— Любые заблокированные сайты\n\n"
            "📍 Сервера в Европе и Азии — выбираешь сам."
        )
        await query.edit_message_text(text, parse_mode="Markdown",
                                      reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == "install":
        keyboard = [[InlineKeyboardButton("◀️ Назад", callback_data="back")]]
        text = (
            "📱 *Как установить Happ VPN*\n\n"
            "*На телефоне (Android / iOS):*\n"
            "1. Скачай приложение *Happ* из App Store / Google Play\n"
            "2. После оплаты ты получишь ключ (ссылку)\n"
            "3. Вставь ключ в приложение → нажми подключиться\n"
            "4. Готово ✅\n\n"
            "*На компьютере (Windows / Mac):*\n"
            "1. Скачай *Hiddify* или *v2rayN*\n"
            "2. Импортируй полученный ключ\n"
            "3. Подключайся\n\n"
            "❓ Возникли вопросы — пиши в поддержку, помогу настроить."
        )
        await query.edit_message_text(text, parse_mode="Markdown",
                                      reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == "why":
        keyboard = [[InlineKeyboardButton("💳 Купить — 120 ₽", callback_data="buy")],
                    [InlineKeyboardButton("◀️ Назад", callback_data="back")]]
        text = (
            "🌍 *Зачем VPN в России в 2025?*\n\n"
            "Роскомнадзор активно блокирует сайты через *белые списки* — "
            "это значит что обычные VPN уже не всегда работают.\n\n"
            "Happ использует современный протокол *VLESS + XTLS*, "
            "который маскирует трафик под обычный HTTPS — "
            "его практически невозможно заблокировать.\n\n"
            "📊 *Что заблокировано:*\n"
            "— Instagram — заблокирован\n"
            "— YouTube — замедлен\n"
            "— Discord — периодически\n"
            "— Сотни других сайтов\n\n"
            "✅ С Happ всё это работает как раньше."
        )
        await query.edit_message_text(text, parse_mode="Markdown",
                                      reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == "support":
        keyboard = [[InlineKeyboardButton("◀️ Назад", callback_data="back")]]
        text = (
            f"💬 *Поддержка*\n\n"
            f"По всем вопросам пиши: {CONTACT}\n\n"
            "Отвечаем обычно в течение часа.\n\n"
            "🕐 Время работы: 9:00 – 23:00"
        )
        await query.edit_message_text(text, parse_mode="Markdown",
                                      reply_markup=InlineKeyboardMarkup(keyboard))

    elif data == "back":
        text = (
            f"👋 Главное меню *{VPN_NAME}*\n\n"
            "Выбери что тебя интересует 👇"
        )
        await query.edit_message_text(text, parse_mode="Markdown", reply_markup=main_menu())

# ─── ПОЛУЧЕНИЕ СКРИНА ОПЛАТЫ ──────────────────────────────────
async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if context.user_data.get("waiting_receipt"):
        context.user_data["waiting_receipt"] = False
        user = update.effective_user
        username = f"@{user.username}" if user.username else f"id{user.id}"

        # Уведомить админа
        if ADMIN_ID:
            await context.bot.send_photo(
                chat_id=ADMIN_ID,
                photo=update.message.photo[-1].file_id,
                caption=f"💳 Новая оплата!\nПользователь: {username} ({user.id})\nИмя: {user.full_name}"
            )

        await update.message.reply_text(
            "✅ *Чек получен!*\n\n"
            "Проверяем оплату — ключ пришлём в течение 5–15 минут.\n\n"
            "Спасибо что выбрал Happ VPN 🙏",
            parse_mode="Markdown"
        )
    else:
        await update.message.reply_text(
            "Напиши /start чтобы открыть меню.",
            parse_mode="Markdown"
        )

# ─── ОТПРАВИТЬ КЛЮЧ ПОЛЬЗОВАТЕЛЮ (команда для админа) ─────────
async def send_key(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    # Использование: /sendkey USER_ID ключ
    try:
        args = context.args
        user_id = int(args[0])
        key = " ".join(args[1:])
        await context.bot.send_message(
            chat_id=user_id,
            text=(
                f"🎉 *Твой ключ Happ VPN готов!*\n\n"
                f"`{key}`\n\n"
                "📱 *Как использовать:*\n"
                "1. Скопируй ключ выше\n"
                "2. Открой приложение Happ\n"
                "3. Вставь ключ → подключись\n\n"
                "❓ Вопросы — /start → Поддержка"
            ),
            parse_mode="Markdown"
        )
        await update.message.reply_text(f"✅ Ключ отправлен пользователю {user_id}")
    except Exception as e:
        await update.message.reply_text(f"Ошибка: {e}\nИспользование: /sendkey USER_ID ключ")

# ─── ЗАПУСК ───────────────────────────────────────────────────
def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("sendkey", send_key))
    app.add_handler(CallbackQueryHandler(button))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    print("Бот запущен ✅")
    app.run_polling()

if __name__ == "__main__":
    main()
